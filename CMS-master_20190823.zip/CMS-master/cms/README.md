Inventory setting -- Following field must be 'True'
---------------

1). Delivery Packages --> True
2). Product Packagings --> True
3). Lots & Serial Numbers --> True
4). Display Lots & Serial Numbers --> True
5). Storage Locations --> True
6). Multi-Warehouses --> True
